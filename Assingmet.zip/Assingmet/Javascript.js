<html>  
<body>  
<script type="text/javascript">  
 alert("Hello Javatpoint");  
</script>  
</body>  
</html>  